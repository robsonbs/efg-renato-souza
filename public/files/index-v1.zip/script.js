// Armazena usuários fictícios (em um projeto real, você usaria uma API)
const users = JSON.parse(localStorage.getItem('users')) || [];

function login() {
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;

    const user = users.find(u => u.username === username && u.password === password);

    if (user) {
        localStorage.setItem('loggedInUser', JSON.stringify(user));
        window.location.href = 'index.html';
    } else {
        alert('Usuário ou senha inválidos!');
    }
}

function register() {
    const newUsername = document.getElementById('newUsername').value;
    const newPassword = document.getElementById('newPassword').value;

    if (users.some(u => u.username === newUsername)) {
        alert('Usuário já existe!');
        return;
    }

    users.push({ username: newUsername, password: newPassword });
    localStorage.setItem('users', JSON.stringify(users));
    alert('Cadastro realizado com sucesso!');
    window.location.href = 'login.html';
}

function logout() {
    localStorage.removeItem('loggedInUser');
    window.location.href = 'login.html';
}

// Verifica se o usuário está logado ao carregar a página index.html
window.onload = () => {
    const loggedInUser = localStorage.getItem('loggedInUser');
    const isLoggedPage = !!document.querySelector('#index')

    if (isLoggedPage && !loggedInUser) {
        window.location.href = 'login.html';
    } else {
        const user = JSON.parse(loggedInUser);
        document.getElementById('userName').innerText = user.username;
    }
};

// Event listeners para os formulários
let loginform = document.getElementById('loginForm');
if (loginform) {
    loginform.addEventListener('submit', e => {
        e.preventDefault();
        login();
    });
}
let registerForm = document.getElementById('registerForm')
if (registerForm) {
    registerForm.addEventListener('submit', e => {
        e.preventDefault();
        register();
    });
}