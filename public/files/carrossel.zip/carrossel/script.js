// Array de imagens
const images = [
    'image1.jpg',
    'image2.jpg',
    'image3.jpg',
    'image4.jpg',
    'image5.jpg'
];

let currentIndex = 0;

function showImage(index) {
    const imagesContainer = document.querySelector('.carousel');
    
    // Ocultar todas as imagens
    images.forEach((_, i) => {
        document.getElementById(`image${i + 1}`).style.display = 'none';
    });
    
    // Exibir a imagem atual
    document.getElementById(`image${index + 1}`).style.display = 'block';
}

function nextImage() {
    currentIndex = (currentIndex + 1) % images.length;
    showImage(currentIndex);
}

function prevImage() {
    currentIndex = (currentIndex - 1 + images.length) % images.length; // Garante que o índice não seja negativo
    showImage(currentIndex);
}
// Iniciar o carrossel
showImage(currentIndex);

// Atualizar a imagem a cada 10 segundos
// setInterval(nextImage, 10000);
